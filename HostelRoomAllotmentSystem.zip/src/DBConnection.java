import java.sql.*;

public class DBConnection {
    // Update these constants with your MySQL credentials
    static final String URL = "jdbc:mysql://localhost:3306/hostel_db?useSSL=false&serverTimezone=UTC";
    static final String USER = "root";
    static final String PASS = "your_password";

    public static Connection getConnection() {
        try {
            // Optionally load driver: Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            System.out.println("DB connection failed: " + e.getMessage());
            return null;
        }
    }
}
